//
//  AppStoreViewModel.swift
//  UikitPlayground
//
//  Created by yongbeomkwak on 2023/06/04.
//

import Foundation

class AppStoreViewModel:ViewModelType{
    
    public struct Input{
        
    }
    
    public struct Output{
        
    }
    
    public func transform(from input: Input) -> Output {
        
        return Output()
    }
    
}
